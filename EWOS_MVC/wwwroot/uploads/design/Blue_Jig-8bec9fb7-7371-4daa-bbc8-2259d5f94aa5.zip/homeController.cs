public class HomeController : Controller
{
    private readonly ILogger<HomeController> _logger;

    // Konstruktor untuk HomeController
    public HomeController(ILogger<HomeController> logger)
    {
        _logger = logger;  // Inisialisasi logger
    }

    // Action untuk halaman Index
    public IActionResult Index()
    {
        _logger.LogInformation("User accessed the Index page.");  // Contoh penggunaan logger
        return View();
    }

    // Action untuk halaman SingleLine
    public IActionResult SingleLine()
    {
        _logger.LogInformation("User accessed the SingleLine page.");
        return View();
    }

    // Action untuk halaman Multiline
    public IActionResult MultiLine()
    {
        _logger.LogInformation("User accessed the MultiLine page.");
        return View();
    }
}
